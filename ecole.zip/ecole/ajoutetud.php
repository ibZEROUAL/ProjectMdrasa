<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?>
<!DOCTYPE html>
<html>
<head>
    <title>New etudiant</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <div scope="col"><a style="text-decoration-color: #171a1d; margin-top: 30px; margin-left: 150px;" role="button" class="btn btn-outline-secondary" href="students.php">Retour</a></div>

</head>
<body>
<h1 align="center" class="display-4"">Ajouter un étudiant</h1>

<div class="container" style="width: 40%; margin-top: -10px; background-color: #ebecec" >

    <div class="p-3 mb-2 text-dark">
    <form action="insertetud.php" method="get">
        <div class="form-group">
            <label>login</label>
            <input type="email" class="form-control" name="login" required>
        </div>
        <div class="form-group">
            <label>Nom</label>
            <input type="text" class="form-control" name="nom">
        </div>
        <div class="form-group">
                <label>Branche</label>

                <select class="custom-select"  name="brch">
                    <option value="ISI" selected>ISI</option>
                    <option value="MGE">MGE</option>
                    <option value="MIL">MIL</option>
                </select>
            </div>
        <div class="form-group">
            <label>Telephone</label>
            <input type="number" name="tel" class="form-control">
        </div>
        <div class="form-group">
            <label>password</label>
            <input type="password" class="form-control" name="pass">
        </div>
        <div align="center"><button type="submit" class="btn btn-primary">Submit</button></div>
    </form>
</div>
</div>
</body>
</html>