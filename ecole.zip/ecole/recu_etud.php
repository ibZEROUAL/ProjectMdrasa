<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?><?php
 require 'connexion.php';
$num_etu=$_POST['num'];
$nom_etu=$_POST['nom_etu'];
$date_recu=$_POST['date_recu'];
$montant_recu=$_POST['montant_recu'];

     $query="insert into reçus(nom_etud,date_reçus,montant,num_e) values ('$nom_etu','$date_recu','$montant_recu','$num_etu') ";

      mysqli_query($con , $query);

     header('location:students.php');

//require 'fpdf/fpdf.php';


//$pdf = new FPDF();
//$pdf->AddPage();
//$pdf->SetFont('Arial', 'B', 16);
//$pdf->Cell(40, 10, 'Hello World!');
