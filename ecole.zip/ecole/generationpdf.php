<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?><?php
require 'connexion.php';
require ('fpdf/fpdf.php');

$numetu =$_GET['num'];

$query="select num_reçus from reçus,etudiant where reçus.num_e='$numetu'";
$result= mysqli_query($con,$query);
$rec = mysqli_fetch_row($result);

if(mysqli_num_rows($result)!=0) {

    $query = mysqli_query($con, "select * from reçus inner join etudiant using (num_e)  where num_reçus ='$rec[0]'");
    $genpdf = mysqli_fetch_array($query);


    $pdf = new FPDF('p', 'mm', 'A4');
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 20);
    $pdf->Cell(100, 10, 'Numero de Recu', 0, 0);
    $pdf->Cell(40, 10, $genpdf['num_reçus'], 0, 1);

    $pdf->Cell(40, 10, '', 0, 1);
    $pdf->Cell(40, 10, '', 0, 1);

    $pdf->Cell(100, 10, 'Nom etudiant', 0, 0);
    $pdf->Cell(40, 10, $genpdf['nom_e'], 0, 1);

    $pdf->Cell(40, 10, '', 0, 1);
    $pdf->Cell(40, 10, '', 0, 1);

    $pdf->Cell(100, 10, 'Mois', 0, 0);
    $pdf->Cell(40, 10, $genpdf['date_reçus'], 0, 1);

    $pdf->Cell(40, 10, '', 0, 1);
    $pdf->Cell(40, 10, '', 0, 1);

    $pdf->Cell(100, 10, 'Montant', 0, 0);
    $pdf->Cell(40, 10, $genpdf['montant'], 0, 1);

    $pdf->Cell(40, 10, '', 0, 1);
    $pdf->Cell(40, 10, '', 0, 1);

    $pdf->Cell(100, 10, 'Num etudiant', 0, 0);
    $pdf->Cell(40, 10, $genpdf['num_e'], 0, 1);

    $pdf->Output();
}

?>