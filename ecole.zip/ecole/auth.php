<!DOCTYPE html>

<div>
    <head>
        <title>Authentification</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
    </head>
    <body>
    <script type="text/javascript">

        function afficher() {

            if(document.getElementById('vmp').checked==true)
                document.getElementById('pass').type="text";
            else
                document.getElementById('pass').type="password";
        }

      //  function verif(){
        //    if(document.getElementById('login').value=='')
          //  {
            //    alert('Attention login obligatoire');
              //  return false;
            //}
            //if(document.getElementById('pass').value=='')
            //{
              //  alert('Attention mot de passe obligatoire');
               // return false;
            //}
       // }</script>

    </body>
    <div class="container" style="width: 35%; margin-top: 65px">
        <div class="p-3 mb-2 text-dark" style="background-color: #ebecec">
        <?php
        if(isset($_GET['authentification']))
            if($_GET['authentification']=='false')
            {
                ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>INVALID INFORMATIONS !</strong> You should check in on some of those fields below.
                    </button>
                </div>
                <?php
            }
        ?>
        <form action="verifetud.php" method="post" name="monformulaire" onsubmit="return verif()">
            <div class="form-group">

                <label for="exampleInputEmail1">Email address</label>
                <input type="text" class="form-control" name="login" id="login"  aria-describedby="emailHelp" required >
                <small id="emailHelp" class="form-text text-muted">We'll never share your info with anyone else.</small>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control" name="pass" id="pass" required>
            </div>
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="vmp" onclick="afficher()">
                <label class="form-check-label" for="exampleCheck1">Show Password</label>
            </div>
            <input class="btn btn-primary" type="submit" value="Submit">
            <input class="btn btn-primary" type="reset" value="Reset">
            <a class="btn btn-primary" href="inscriptionuser.php" role="button">Inscription</a>

        </form>

    </div>
    </div>
    </html>