



        <form action="students.php" method="post">
           <input type="text" name="critere">
            <select name="field">
                    <option value="a">All</option>
                    <option value="d">nom</option>
                    <option value="s">branche</option>
                </select>
        </form>

