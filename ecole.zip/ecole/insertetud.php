<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?>
<?php
require "connexion.php";

$email=$_GET['login'];
$branche=$_GET['brch'];
$nom=$_GET['nom'];
$tel=$_GET['tel'];
$password=$_GET['pass'];
$realpass=$_GET['pass'];
 
$password=md5($password);

$query = "select login from users where login='$email'";

$result= mysqli_query($con,$query);

if(mysqli_num_rows($result)==0){
    $query="insert into users (login,nom,pass) values ('$email','$nom','$password')";
    mysqli_query($con,$query);

    $query="insert into etudiant (nom_e,branche_e,tel_e,login) values ('$nom','$branche','$tel','$email')";
    mysqli_query($con,$query);
    header('location:students.php?etudiant_insere');
}else{?>

<head>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<div  class="container" style="margin-top: 100px">
   <div  align='center' class='alert alert-warning' role='alert'>
       <a href='ajoutetud.php' class='alert-link'>TRY ANOTHER LOGIN PLEASE</a>
</div>

    <?php
}

 //$email = 'fourniseur147@gmail.com';

 //echo "95zeroual / fourniseur147@gmail.com";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


require 'vendor/autoload.php';

$mail = new PHPMailer(true);
try {

    $mail->SMTPDebug = 2;                               // Enable verbose debug output

    $mail->isSMTP();                                       // Set mailer to use SMTP
    $mail->Host = "smtp.gmail.com";                     // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'fournis07@gmail.com';                 // SMTP username
    $mail->Password = '95zeroual';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    $mail->setFrom('fournis07@gmail.com');
    $mail->addAddress($email);     // Add a recipient

//$mail->addAddress('ellen@example.com');

    $mail->addReplyTo('fournis07@gmail.com');
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');

//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
    $mail->isHTML(true);                                  // Set email format to HTML

    $mail->Subject = 'info de login ';
    $mail->Body = " <b> Votre info de login sont:</b> <br> Login :$email  <br> Password :$realpass ";

//$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
   // header('location : students.php');
    echo "message envoyé !";
} catch  (Exception $e){
    echo "message non envoyé !";
}//header('location:fiche_sugg.php');
?>

