<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?><!DOCTYPE html>
<html>
<head>
    <title>Edit student info</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <div scope="col"><a style="text-decoration-color: #171a1d; margin-top: 20px; margin-left: 100px" role="button" class="btn btn-outline-secondary" href="students.php">Retour</a></div>

    <?php
    $numP=$_GET['num'];
    require 'connexion.php';
    $query="select * from etudiant where num_e=$numP";
    $result = mysqli_query($con, $query);
    $etud=mysqli_fetch_row($result);
    ?>
</head>
<body>
<div class="container" style="width: 41%; margin-top: -40px ">

<form action="updateetud.php" method="post">
    <h1 align="center" class="display-4"">Edit student info</h1>
    <div class="p-3 mb-2 text-dark" style="background-color: #ebecec">
        <form action="insertetud.php" method="get">
            <div class="form-group">

                <label>Numéro</label>
                <input type="text" class="form-control" value="<?php echo $etud[0];?>" readonly>
            </div>
            <div class="form-group">
                <label>Nom</label>
                <input type="text" name="nom" class="form-control" value="<?php echo $etud[1];?>">
            </div>
            <div class="form-group">
                <label>Branche</label>
                <select class="custom-select"  name="br">
                    <option value="ISI" selected>ISI</option>
                    <option value="MGE">MGE</option>
                    <option value="MIL">MIL</option>
                </select>
            </div>
            <div class="form-group">
                <label>Abcences</label>
                <input type="text" name="abs" class="form-control" value="<?php echo $etud[3];?>">
            </div>
            <div class="form-group">
                <label>Telephone</label>
                <input type="text" name="tel" class="form-control" value="<?php echo $etud[5];?>">
            </div>
            <div align="center"><button type="submit" class="btn btn-primary">Submit</button></div>
            <input type="hidden" name="num" value="<?php echo $etud[0];?>">
        </form>
    </div>
</div>
</body>
</html>
