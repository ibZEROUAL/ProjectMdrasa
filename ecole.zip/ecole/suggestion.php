<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?><!DOCTYPE html>
<html>
<head>

    <?php

    require 'connexion.php';


    if($_SESSION['type']=="AD"){
        $nums='admin';
    }else{
        $nums =$_GET['num'];
    }

    ?>
    <title>Nouvelle suggestion </title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <div scope="col"><a style="text-decoration-color: #171a1d; margin-top: 30px; margin-left: 150px;" role="button" class="btn btn-outline-secondary" href="students.php">Retour</a></div>

</head>
<body>

<div class="container" style="width: 40%; margin-top: 30px">

    <div class="p-3 mb-2 text-dark" style="background-color: #ebecec">
        <form action="insertsuggestion.php" method="post">
            <div class="form-group">

                <label>Categorie du suggestion</label>

                <select class="custom-select"  name="nom_sug">
                    <option value="chaise" selected>chaise</option>
                    <option value="table">table</option>
                    <option value="pc">PC</option>
                </select>
            </div>
            <div class="form-group">
                <label>Description de suggestion</label>
                <textarea class="form-control" name="desc_suggestion"></textarea>
            </div>
            <div class="form-group">
                <label>Num d'etudiant</label>
                <input type="text" class="form-control" name="num_etud"  value=" <?php echo $nums?>" readonly>
            </div>
            <div align="center"><button type="submit" class="btn btn-primary">Submit</button></div>
        </form>
    </div>
</div>
</body>
</html>