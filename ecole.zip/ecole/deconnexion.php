<?php
//setcookie('user',$_COOKIE['user'],time()-1);
  session_start();
  unset($_SESSION['user']);
  session_destroy();
header('location:auth.php');
?>