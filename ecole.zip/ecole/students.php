
<?php
require 'connexion.php';
//if(!isset($_COOKIE['user'])) header('location:auth.php');
session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');

//$numre = $_GET['num_recu'];
//echo $numre;
$usr = $_SESSION['user'];

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <div  class="container-fluid" style="width: 90%">
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #ebecec;">
        <a class="navbar-brand btn btn-outline-danger" href="deconnexion.php">Deconnexion</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <?php
                    if($_SESSION['type']=="AD")
                    {
                    ?>
                        <a class="navbar-brand btn btn-outline-secondary" href="rec.php"> List des Reçus <span class="sr-only">(current)</span></a>
                        <a class="navbar-brand btn btn-outline-secondary" href="fiche_sugg.php">List des Suggestions<span class="badge badge-primary badge-pill"></span></a>
                        <a class="navbar-brand btn btn-outline-secondary" href="demandes.php" >List des Demandes<span class="badge badge-primary badge-pill"></span></a>

                        <?php
                    }else{
       $query="select * from etudiant where login='$usr'";
        $result = mysqli_query($con, $query);
        $etu = mysqli_fetch_row($result);

                        ?>

            <a class="navbar-brand btn btn-outline-secondary" href="demandedocs.php?num=<?php echo $etu[0];?>"> Demande des docs <span class="sr-only">(current)</span></a>


                        <?php
                    }
                    ?>
                </li>
             <!--   <li class="nav-item">
                    <a class="navbar-brand btn btn-outline-secondary" href="students.php">Accueil</a>
                </li> -->
            </ul>
            <?php
            if($_SESSION['type']=="AD")
            {
            ?>
            <form class="form-inline my-2 my-lg-0" action="students.php" method="post">
                <input class="form-control mr-sm-2" style="width: 150px" type="search"  placeholder="Search" aria-label="Search"  type="text" name="critere">
                <select class="custom-select" name="field">
                    <option value="a" selected>All</option>
                    <option value="d">Nom</option>
                    <option value="s">Branche</option>
                </select>
                <button class="btn btn-outline-secondary my-2 my-sm-0" type="submit">Search</button>
            </form>

                <?php
            }
            ?>
        </div>
    </nav>
</head>
<body>
<?php
if($_SESSION['type']=="AD")
{
?>
<div align="left" class="alert alert-primary" role="alert" style="width:50%">Bonjour<b> <?php echo $usr; ?></b> n'oubliez pas de vérifier les listes de Suggestions et Demandes!
</div><br>
    <?php
}else{?>
    <div align="left" class="alert alert-primary" role="alert" style="width:30%">Bonjour<b> <?php echo $usr; ?></b></div><br><?php
}
?>


<h1 align="center" class="display-4">Gestion des Etudiants</h1>


 <?php

    $querycriterion="1";
    if(isset($_POST['critere']))
        {$critere=$_POST['critere'];
        switch($_POST['field'])
        {
         case 'd':$querycriterion="etudiant.`nom_e` like '%$critere%'"; break;
         case 's':$querycriterion="etudiant.`branche_e` like '%$critere%' "; break;
         default :$querycriterion="(etudiant.`nom_e` like '%$critere%' or etudiant.`branche_e` like '%$critere%')";
        }
        }
    ?>

<div align="right" style="margin-right: -15px">
<?php

                if ($_SESSION['type'] == "AD")
                {
                ?>
     <a class="navbar-brand btn btn-outline-primary text-dark" href="msgetud.php">Envoyer un message a tout les éudiants<span
                                class="sr-only">(current)</span></a>
    <a class="navbar-brand btn btn-outline-secondary text-dark" href="suggestion.php">Suggérer<span
                                class="sr-only">(current)</span></a>
<a class="navbar-brand btn btn-outline-secondary text-dark" href="ajoutetud.php"> Ajouter un Etudiant <span
            class="sr-only">(current)</span></a>
<?php
}

?></div>
<table class="table table-bordered">
    <thead class="thead-light">
    <tr align="center">
        <th scope="col">Num_etudiant</th>
        <th scope="col">Nom_etudiant</th>
        <th scope="col">branche_etudiant</th>
        <th scope="col">abcences_etudiant</th>
        <th scope="col">paiement</th>
        <th scope="col">tel_etudiant</th>
        <th scope="col" colspan="3">Customize</th>

    </tr>
    </thead>
    <tbody>
    <?php if($_SESSION['type']=='user'){
        $query="select etudiant.num_e,etudiant.nom_e,etudiant.branche_e,etudiant.absences_e,etudiant.paiement,etudiant.tel_e,etudiant.login from etudiant where etudiant.login='$usr'";
    }else{
        $query="select etudiant.num_e,etudiant.nom_e,etudiant.branche_e,etudiant.absences_e,etudiant.paiement,etudiant.tel_e from etudiant where $querycriterion";
    }
    //echo $query;
    $result = mysqli_query($con, $query);
    $nb=mysqli_num_rows($result);
    if(!$nb){echo"<h4><center>Aucun Etudiants</center></h4>";}
    else{
    $etudiant=mysqli_fetch_all($result);
    foreach($etudiant as $etud)
    {
    //if($etud[6]=='') $image="images/photo.png";
    //else $image="photos/$etud[6].jpeg";
    ?>
    <tr align="center">
        <td><?php echo $etud[0]; ?></td>
        <td><?php echo $etud[1]; ?></td>
        <td><?php echo $etud[2]; ?></td>
        <td><?php echo $etud[3]; ?></td>
        <td>
            <?php
            if($_SESSION['type']=="user"){
            $query="select num_reçus,paiement from reçus,etudiant where reçus.num_e=$etud[0]";
            $result=mysqli_query($con,$query);
            if(mysqli_num_rows($result)!=0){
                $etud[4]=true;

                $query="update etudiant set paiement=1";
                mysqli_query($con,$query);
            }
            if(mysqli_num_rows($result)==0){
                $etud[4]=false;

                $query="update etudiant set paiement=0";
                mysqli_query($con,$query);
            }
            if ($etud[4]==true){
            ?>
                <div class="custom-control custom-switch">
                  <input type="checkbox" class="custom-control-input" id="customSwitch1" checked disabled>
                  <label class="custom-control-label" for="customSwitch1">Payé</label>
               <?php }

               else {
                ?>
                  <div class="custom-control custom-switch">
                  <input type="checkbox" class="custom-control-input" id="customSwitch1" disabled >
                  <label class="custom-control-label" for="customSwitch1">Non Payé</label>

            <?php } }

            if($_SESSION['type']=="AD"){

                 $query="select num_reçus,paiement from reçus,etudiant where reçus.num_e=$etud[0]";
                         $result=mysqli_query($con,$query);
                         if(mysqli_num_rows($result)!=0){
                             $etud[4]=true;

                                 $query="update etudiant set paiement=1";
                             mysqli_query($con,$query);
                                                 }
                             if(mysqli_num_rows($result)==0){
                                 $etud[4]=false;

                                 $query="update etudiant set paiement=0";
                                  mysqli_query($con,$query);
                             }
                             if ($etud[4]==true){
                                 ?>
                          <div class="custom-control custom-switch">
                          <input type="checkbox" class="custom-control-input" id="customSwitch1" checked  disabled>
                          <label class="custom-control-label" for="customSwitch1">Payé</label>
                          <?php  }

                       else {?>

                          <div class="custom-control custom-switch">
                              <input type="checkbox" class="custom-control-input" id="customSwitch1" disabled >
                              <label class="custom-control-label" for="customSwitch1">Non Payé</label>

                              <?php }}?>


        <td><?php echo $etud[5]; ?></td>
        <?php
        if($_SESSION['type']=="AD")
        {
        ?>
            <td><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="deletud.php?num=<?php echo $etud[0];?>" onclick="return confirm('Est ce que vous voulez effacer!')">Supprimer</a></td>
            <td><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="editetud.php?num=<?php echo $etud[0];?>">Modifier</a></td>
        <td><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="recu.php?num=<?php echo $etud[0];?>">Reçu</a></td>

            <?php
        }else{
            ?>
        <td colspan="2"><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="suggestion.php?num=<?php echo $etud[0];?>">suggérer</a></td>

            <?php
            if($_SESSION['type']=="user"){

                if($etud[4]==true){ ?>
                    <td colspan="2"><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="generationpdf.php?num=<?php echo $etud[0];?>">Download reçu</a></td>

                <?php }

                else {
                    ?>
                    <td colspan="2"><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary disabled " href="generationpdf.php?num=<?php echo $etud[0];?>" aria-disabled="true" >Download reçu</a></td>

                <?php }}?>
                    </td>
                <?php }}}?>


        </div>
    </tr>
    </tbody>
</table>
</body>
</html>
<!-- <td><a href="editPhoto.php?num=<?php //echo $etud[0];?>"><img src=images/photo.png" width="20" height="30"></a></td>-->
