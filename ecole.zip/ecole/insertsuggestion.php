<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?><!DOCTYPE html>
<html>
<head>
    <title>insert suggestion</title>
</head>
<body>
<?php
    require "connexion.php";


if($_SESSION['type']=="AD"){
    $nom_s=$_POST['nom_sug'];
    $desc_s=$_POST['desc_suggestion'];
    $num_s=$_POST['num_etud'];

    $query="insert into fiche_suggestion (nom_suggestion,desc_suggestion,admin,num_e) values ('$nom_s','$desc_s','$num_s',20)";

    mysqli_query($con,$query);

}else{

    $nom_s=$_POST['nom_sug'];
    $desc_s=$_POST['desc_suggestion'];
    $num_s=$_POST['num_etud'];

    $query="insert into fiche_suggestion (nom_suggestion,desc_suggestion,num_e) values ('$nom_s','$desc_s','$num_s')";

     mysqli_query($con,$query);
}
     header("location:students.php");
?>
</body>
</html>