<?php
//if(!isset($_COOKIE['user'])) header('location:auth.php');
session_start();
if(!isset($_SESSION['user'])) header('location:auth.php');
	//require 'trace.php';
    require 'connexion.php' ;
    $numg=$_GET['num'] ;

    $query="delete from commande where num_suggestion=$numg" ;
    mysqli_query($con , $query) ;

    $query="delete from fiche_suggestion where num_suggestion=$numg" ;
    mysqli_query($con , $query) ;
   // trace($query);
   
    header('location:fiche_sugg.php');

   // echo "suppression faite";
?>