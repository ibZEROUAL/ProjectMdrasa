<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?>
<?php
	$login=$_POST['login'];
    $pass=$_POST['pass'];
    $pass=md5($pass);
    //echo $login.'#'.$pass;
	require "connexion.php";
    $query="select count(*) from users 
    		where login='$login' and pass='$pass' ";
   // echo $query;
    $result=mysqli_query($con,$query);
    $infoauth=mysqli_fetch_row($result);
    if($infoauth[0]==1) 
    {
        //setcookie('user',$login,time()+180);
        $query="select type 
            from users 
            where login='$login'";
          $result=mysqli_query($con,$query);
          $infotype=mysqli_fetch_row($result);
        session_start();
        $_SESSION['user']=$login;
        $_SESSION['type']=$infotype[0];
        header('location:students.php');
    }

    else header('location:auth.php?authentification=false');
?>