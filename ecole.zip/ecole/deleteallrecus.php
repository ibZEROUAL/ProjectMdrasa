<?php

//if(!isset($_COOKIE['user'])) header('location:auth.php');
session_start();
if (!isset($_SESSION['user'])) header('location:auth.php');

require 'connexion.php';
$query = "select * from reçus";
$result = mysqli_query($con, $query);
$recu=mysqli_fetch_all($result);

foreach ($recu as $re) {


   $query = "delete from reçus where num_reçus=$re[0]";
    mysqli_query($con, $query);
}


header('location:rec.php');



