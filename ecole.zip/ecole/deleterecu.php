<?php

//if(!isset($_COOKIE['user'])) header('location:auth.php');
session_start();
if (!isset($_SESSION['user'])) header('location:auth.php');
//require 'trace.php';
require 'connexion.php';
$numg = $_GET['num'];
$query = "delete from reçus where num_reçus=$numg";
mysqli_query($con, $query);
// trace($query);

header('location:rec.php');

// echo "suppression faite";


?>