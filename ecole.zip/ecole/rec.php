<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?><html>
<head>
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>



<div  class="container">
    <div align="center" class="alert alert-primary" role="alert">
        Bonjour n'oubliez pas de supprimer tout les reçus chaque mois !
    </div>

    <td scope="col"><a style="text-decoration-color: #171a1d; margin-top: 20px" role="button" class="btn btn-outline-secondary" href="students.php">Retour</a></td>

    <h1 align="center" class="display-4"">Liste des Reçus</h1>


    <table class="table table-bordered">
    <thead class="thead-light">
    <tr align="center">
        <th scope="col">Num_reçus</th>
        <th scope="col">Nom_etudiant</th>
        <th scope="col">date_recus</th>
        <th scope="col">montant</th>
        <th scope="col">num_etudiant</th>
        <th scope="col"><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="deleteallrecus.php">Supprimer tout les Reçus</a>
        </th>
    </tr>
    </thead>
    <tbody>

<?php


require 'connexion.php';

  $query= "select * from reçus";

$result = mysqli_query($con, $query);
$nb=mysqli_num_rows($result);
if(!$nb){echo"<h4><center>Aucun Reçus</center></h4>";}
else{
$recus=mysqli_fetch_all($result);
foreach($recus as $recu){

?>
<tr align="center">
    <td><?php echo $recu[0]; ?></td>
    <td><?php echo $recu[1]; ?></td>
    <td><?php echo $recu[2]; ?></td>
    <td><?php echo $recu[3]; ?></td>
    <td><?php echo $recu[4]; ?></td>
    <td><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="deleterecu.php?num=<?php echo $recu[0];?>">Supprimer</a></td>

</tr>

    </tbody>
<?php } }?>
</html>
