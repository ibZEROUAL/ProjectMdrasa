<html>
<head>
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<div  class="container">

<div  class="container">
<table class="table table-bordered">
    <thead class="thead-light">
    <tr align="center">
        <th scope="col">Num_reçus</th>
        <th scope="col">Nom_etudiant</th>
        <th scope="col">date_recus</th>
        <th scope="col">montant</th>
        <th scope="col">num_etudiant</th>
    </tr>
    </thead>
    <tbody>

<?php

require 'connexion.php';

  $query= "select * from reçus";

$result = mysqli_query($con, $query);
$nb=mysqli_num_rows($result);
if(!$nb){echo"<h4><center>Aucun Reçus</center></h4>";}
else{
$recus=mysqli_fetch_all($result);
foreach($recus as $recu){

?>
<tr align="center">
    <td><?php echo $recu[0]; ?></td>
    <td><?php echo $recu[1]; ?></td>
    <td><?php echo $recu[2]; ?></td>
    <td><?php echo $recu[3]; ?></td>
    <td><?php echo $recu[4]; ?></td>
</tr>

    </tbody>
<?php } }?>
</html>
