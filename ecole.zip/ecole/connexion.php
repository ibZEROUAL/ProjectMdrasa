<?php
    
    define("HOST","127.0.0.1");
    define("USER","root");
    define("PASS","");
    define("BASE","ecole");
  
    $con=mysqli_connect(HOST,USER,PASS,BASE);
    if($con==false) {
        //die("probleme de connection");
        echo "probleme de connection";
        exit();
    }
?>

    
