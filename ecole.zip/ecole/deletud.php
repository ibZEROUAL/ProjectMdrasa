<?php
//if(!isset($_COOKIE['user'])) header('location:auth.php');
session_start();
if(!isset($_SESSION['user'])) header('location:auth.php');
	//require 'trace.php';
    require 'connexion.php' ;
    $nump=$_GET['num'] ;


$query="delete from fiche_suggestion where num_e='$nump'" ;
mysqli_query($con , $query) ;

$query="delete from reçus where num_e=$nump" ;
mysqli_query($con , $query) ;

$query="select login from etudiant where num_e='$nump'" ;
$result = mysqli_query($con , $query) ;
$etu = mysqli_fetch_row($result);


$query="delete from users where login='$etu[0]'" ;
mysqli_query($con , $query) ;



    $query="delete from etudiant where num_e='$nump'" ;
    mysqli_query($con , $query) ;


header('location:students.php');

   // trace($query);



?>
