<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?>
<?php

$numP = $_GET['num'];
if(!isset($numP)){header('location:students.php?undefined_num_etudiant');}
require 'connexion.php';
$query = "select * from etudiant where num_e=$numP";
$result = mysqli_query($con, $query);
$etud = mysqli_fetch_row($result);
?>
<!DOCTYPE html>
<html>
<head>
    <title>page de recu </title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <div scope="col"><a style="text-decoration-color: #171a1d; margin-top: 30px; margin-left: 150px;" role="button" class="btn btn-outline-secondary" href="students.php">Retour</a></div>

</head>
<body>

<div class="container" style="width: 40%; margin-top: px">
    <h1 align="center" class="display-4"">Créé un Reçu</h1>

    <div class="p-3 mb-2 text-dark" style="background-color: #ebecec">

        <form action="recu_etud.php" method="post">
            <div class="form-group">
                <label>Num etudiant</label>
                <input readonly name="num" class="form-control" value="<?php echo $etud[0];?>">
            </div>
            <div class="form-group">
                <label>Nom etudiant</label>
                <input readonly name="nom_etu" class="form-control" value="<?php echo $etud[1];?>">
            </div>
            <div class="form-group">
                <label>Mois</label>
                <input readonly class="form-control"  name="date_recu" value="<?php echo date('Y-m-d' );?>">
            </div>
            <div class="form-group">
                <label>Montant</label>
                <input type="number" class="form-control" name="montant_recu">
            </div>
            <div align="center"><button type="submit" class="btn btn-primary">Submit</button></div>
        </form>
    </div>
</div>
</body>
</html>