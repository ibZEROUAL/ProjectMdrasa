<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?>
<!DOCTYPE html>
<html>
<head>
    <?php
    require 'connexion.php';
 
    ?>
    <title>Le message à envoyer </title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <div scope="col"><a style="text-decoration-color: #171a1d; margin-top: 30px; margin-left: 150px;" role="button" class="btn btn-outline-secondary" href="students.php">Retour</a></div>

</head>
<body>

<div class="container" style="width: 40%; margin-top: 30px">
    <h1 align="center" class="display-4">Le message à envoyer</h1>

    <div class="p-3 mb-2 text-dark" style="background-color: #ebecec">
        <form action="sendmsg.php" method="post">
            <div class="form-group">
                <label></label>
                <textarea class="form-control" name="message" rows="5"></textarea>
            </div>
            <div align="center"><button type="submit" class="btn btn-primary">Submit</button></div>
        </form>
    </div>
</div>
</body>
</html>