<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?><?php
require 'connexion.php';

 $cate =$_POST['cate'];
 $extra =$_POST['ex'];
 $num =$_POST['num_etud'];

     $query = "insert into docs(categorie,extra,num_e) values ('$cate','$extra','$num')";
     mysqli_query($con,$query);
     header('location:students.php');
    ?>