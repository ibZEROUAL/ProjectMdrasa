<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?><?php
    require "connexion.php";

    $numP=$_POST['num'];
    $nom=$_POST['nom'];
    $branche=$_POST['br'];
    $absences=$_POST['abs'];
    $pay=$_POST['paiement'];
    $tel=$_POST['tel'];

    $query="update etudiant set 
            nom_e='$nom',
           branche_e='$branche',
           absences_e='$absences',
           paiement='$pay',
           tel_e='$tel'
           where num_e=$numP";
    //echo $query;
    mysqli_query($con,$query);

    $query="select login from etudiant where num_e='$numP'";

    $result = mysqli_query($con,$query);

    $login = mysqli_fetch_row($result);


    $query="update users set 
            nom='$nom'  where users.login='$login[0]' ";


      mysqli_query($con,$query);

    //print_r($result) ;
    header('location:students.php');
?>

