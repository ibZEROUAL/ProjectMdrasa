<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?><?php
require 'connexion.php';
 $nums = $_GET['num'];

     $query = "select nom_suggestion from fiche_suggestion where num_suggestion = $nums";
     $result = mysqli_query($con, $query);
     $sug = mysqli_fetch_row($result);


      $query = "select cat_fournisseur from fournisseur where cat_fournisseur = '$sug[0]'";
      $result = mysqli_query($con, $query);
      $for = mysqli_fetch_row($result);


      $query = "select nom_produit from fiche_produit where nom_produit= '$sug[0]' ";
      $result = mysqli_query($con, $query);
      $prod = mysqli_fetch_row($result);

     ?>

<!DOCTYPE html>
<html>
<head>
    <title>page de commande </title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <div scope="col"><a style="text-decoration-color: #171a1d; margin-top: 20px; margin-left: 150px;" role="button" class="btn btn-outline-secondary" href="fiche_sugg.php">Retour</a></div>

</head>
<body>

<div class="container" style="width: 40%; margin-top: -30px">
    <h1 align="center" class="display-4"">Crée une Commande</h1>

    <div class="p-3 mb-2 text-dark" style="background-color: #ebecec">

        <form action="sendcde.php" method="post">
            <div class="form-group">
                <label>Num suggestion</label>
                <input readonly name="num_sug" class="form-control" value="<?php echo $nums;?>">
            </div>

            <div class="form-group">

                <div class="form-group">
                    <label>Produit</label>
                    <input readonly name="nom_prod" class="form-control" value="<?php echo $prod[0];?>">
                </div>
            </div>

            <div class="form-group">
                <label>fournisseur de : </label>
                <input readonly name="nom_for" class="form-control" value="<?php echo $for[0];?>">
            </div>

            <div class="form-group">
                <label>Date cde</label>
                <input readonly class="form-control"  name="date_cde" value="<?php echo date('Y-m-d' );?>">
            </div>
            <div class="form-group">
                <label>Quantité</label>
                <input type="number" class="form-control" name="qte">
            </div>
            <div align="center"><button type="submit" class="btn btn-primary">Submit</button></div>
        </form>
    </div>
</div>
</body>
</html>