<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?><?php
   require 'connexion.php';




?>


<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<div  class="container">
    <div scope="col"><a style="text-decoration-color: #171a1d; margin-top: 20px" role="button" class="btn btn-outline-secondary" href="students.php">Retour</a></div>

    <h1 align="center" class="display-4">Liste des Demandes</h1>

    <div  class="container">
        <table class="table table-bordered">
            <thead class="thead-light">
            <tr align="center">
                <th scope="col">Num demande</th>
                <th scope="col">Document demandé</th>
                <th scope="col">Extra remarque </th>
                <th scope="col">Num_etudiant</th>
                <th scope="col" colspan="3">Opérations</th>
            </tr>
            </thead>
            <tbody>


            <?php


            $query = "select * from docs ";
            $result = mysqli_query($con,$query);
            $nb=mysqli_num_rows($result);
            if(!$nb){echo"<h4><center>Aucune demande</center></h4>";}
            else{
                $demande= mysqli_fetch_all($result);
                foreach($demande as $dem)
                {
                    //if($etud[6]=='') $image="images/photo.png";
                    //else $image="photos/$etud[6].jpeg";
                    ?>
                    <?php
                    if($dem[3]=='green')
                    {
                    ?>
                        <tr align="center" class="table-success">
                        <?php
                    }
                            ?>
                    <?php
                    if($dem[3]=='red')
                    {
                        ?>
                        <tr align="center" class="table-danger">
                        <?php
                    }

                    ?>
                    <?php
                    if($dem[3]=='')
                    {
                        ?>
                        <tr align="center">
                        <?php
                    }
                    ?>
                        <td><?php echo $dem[0]; ?></td>
                        <td><?php echo $dem[1]; ?></td>
                        <td><?php echo $dem[2]; ?></td>
                        <td><?php echo $dem[4]; ?></td>

                        <td scope="col"><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="accdem.php?num=<?php echo $dem[0];?>">Accepter</a></td>
                        <td scope="col"><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="refuscause.php?num=<?php echo $dem[0];?>">Refuser</a></td>
                        <td scope="col"><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="comdem.php?num=<?php echo $dem[0];?>">Completer</a></td>
                    </tr>
                    <?php

                }
            }
            ?>
            </tr>

            </tbody>
</html>



</body>
</html>
