<!DOCTYPE html>
<html>
<head>
    <title>New User</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
<div scope="col"><a style="text-decoration-color: #171a1d; margin-top: 20px; margin-left: 120px" role="button" class="btn btn-outline-secondary" href="auth.php">Retour</a></div>


<div class="container" style="width: 40%; margin-top: -15px; background-color: #ebecec" >

    <h1 align="center" class="display-4">Inscription</h1>
<form action="insertuser.php" method="get">
   <div class="form-group">
            <label>Login</label>
            <input type="email" class="form-control" name="login" required>
        </div>
        <div class="form-group">
            <label>Nom</label>
            <input type="text" class="form-control" name="nom">
        </div>
    <div class="form-group">
        <label>Branche</label>

        <select class="custom-select"  name="brch">
            <option value="ISI" selected>ISI</option>
            <option value="MGE">MGE</option>
            <option value="MIL">MIL</option>
        </select>
    </div>
        <div class="form-group">
            <label>Telephone</label>
            <input type="number" name="tel" class="form-control">
        </div>
        <div class="form-group">
            <label>Password</label>
        <input type="password" class="form-control" name="pass" required>
        </div>
        <div align="center"><button type="submit" class="btn btn-primary">Submit</button></div>
    </form>
</div>
</div>
</body>
</html>





