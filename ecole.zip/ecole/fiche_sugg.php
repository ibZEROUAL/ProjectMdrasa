<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?>
<!DOCTYPE html>
<html>
<?php require 'connexion.php'; ?>
<head>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<div  class="container">
    <div scope="col"><a style="text-decoration-color: #171a1d; margin-top: 20px" role="button" class="btn btn-outline-secondary" href="students.php">Retour</a></div>

    <h1 align="center" class="display-4"">Liste des Suggestion</h1>

    <div  class="container">
        <table class="table table-bordered">
            <thead class="thead-light">
            <tr align="center">
                <th scope="col">Num suggestion</th>
                <th scope="col">Suggestion categorie</th>
                <th scope="col">Description suggestion</th>
                <th scope="col">Num_etudiant/Admin</th>
                <th scope="col">Supprimer sugg</th>
                <th scope="col">Faire Commande</th>
            </tr>
            </thead>
            <tbody>


            <?php

            $query="select * from fiche_suggestion";
            //echo $query;
            $result = mysqli_query($con, $query);
            $nb=mysqli_num_rows($result);
            if(!$nb){echo"<h4><center>Aucune suggestion</center></h4>";}
            else{
                $suggestion=mysqli_fetch_all($result);
                foreach($suggestion as $sugg)
                {
                    //if($etud[6]=='') $image="images/photo.png";
                    //else $image="photos/$etud[6].jpeg";
                    ?>
                    <tr align="center">
                        <td><?php echo $sugg[0]; ?></td>
                        <td><?php echo $sugg[1]; ?></td>
                        <td><?php echo $sugg[2]; ?></td>
                        <td><?php if($sugg[3]=='') {echo $sugg[4];} else  {echo $sugg[3];}  ?></td>
                        <td scope="col"><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="delsugg.php?num=<?php echo $sugg[0];?>">Supprimer</a></td>
                        <td scope="col"><a style="text-decoration-color: #171a1d" role="button" class="btn btn-outline-secondary" href="creecde.php?num=<?php echo $sugg[0];?>">Crée une commande</a></td>
                    </tr>
                    <?php

                }
            }
            ?>
            </tr>
            </tbody>
        </table>
        <div align="right">
            <a class="navbar-brand btn btn-outline-secondary text-dark" href="cde.php" style="margin-right: -2px"> list des commandes <span
                        class="sr-only">(current)</span></a>
        </div>

</body>
</html>
