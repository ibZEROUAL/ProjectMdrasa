<!DOCTYPE html>
<?php session_start();
//echo $_SESSION['user'];
//echo $_SESSION['type'];
if(!isset($_SESSION['user'])) header('location:auth.php');?>
<html>
<?php require 'connexion.php'; ?>
<head>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<div  class="container">
    <div scope="col"><a style="text-decoration-color: #171a1d; margin-top: 20px" role="button" class="btn btn-outline-secondary" href="fiche_sugg.php">Retour</a></div>

    <h1 align="center" class="display-4"">Liste des Commandes</h1>

    <div  class="container">
        <table class="table table-bordered">
            <thead class="thead-light">
            <tr align="center">
                <th scope="col">Num commande</th>
                <th scope="col">Date commande</th>
                <th scope="col">Produit</th>
                <th scope="col">Quantité commander</th>
                <th scope="col">Num fournisseur</th>
                <th scope="col">Num suggestion</th>
            </tr>
            </thead>
            <tbody>

            <?php
            $query="select * from commande";
            //echo $query;
            $result = mysqli_query($con, $query);
            $nb=mysqli_num_rows($result);
            if(!$nb){echo"<h4><center>Aucune commande</center></h4>";}
            else{
                $suggestion=mysqli_fetch_all($result);
                foreach($suggestion as $sugg)
                {
                    //if($etud[6]=='') $image="images/photo.png";
                    //else $image="photos/$etud[6].jpeg";
                    ?>
                    <tr align="center">
                        <td><?php echo $sugg[0]; ?></td>
                        <td><?php echo $sugg[1]; ?></td>
                        <td><?php echo $sugg[4]; ?></td>
                        <td><?php echo $sugg[2]; ?></td>
                        <td><?php echo $sugg[3]; ?></td>
                        <td><?php echo $sugg[5]; ?></td>
                    </tr>
                    <?php

                }
            }
            ?>
            </tr>
            </tbody>
        </table>

        </body>
</html>

