
<?php
    require "connexion.php";

    $email=$_GET['login'];
$branche=$_GET['brch'];
$nom=$_GET['nom'];
$tel=$_GET['tel'];
$password=$_GET['pass'];


      $password=md5($password);

 
$query = "select login from users where login='$email'";

$result= mysqli_query($con,$query);

if(mysqli_num_rows($result)==0){

  $query="insert into users (login,nom,pass) values ('$email','$nom','$password')";
 mysqli_query($con,$query);
   $query="insert into etudiant (nom_e,branche_e,tel_e,login) values ('$nom','$branche','$tel','$email')";
    mysqli_query($con,$query);
 header('location:auth.php?etudiant_insere');
}else{?>

<head>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<div  class="container" style="margin-top: 100px">
    <div  align='center' class='alert alert-warning' role='alert'>
        <a href='inscriptionuser.php' class='alert-link'>TRY ANOTHER LOGIN PLEASE</a>
    </div>

<?php
}
?>